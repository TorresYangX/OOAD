package com.example.backendproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendprojectApplicationTests {

    @Test
    void contextLoads() {
    }

}
