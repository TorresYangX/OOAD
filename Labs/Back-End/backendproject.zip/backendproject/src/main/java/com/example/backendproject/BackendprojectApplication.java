package com.example.backendproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendprojectApplication {

    public static void main(String[] args) {
        SpringApplication.run(BackendprojectApplication.class, args);
    }

}
