package com.example.backendproject.service;

import com.example.backendproject.domain.PurchaseRecord;

import java.util.List;

public interface PurchaseRecordService {
    public List<PurchaseRecord> findAll();
}
